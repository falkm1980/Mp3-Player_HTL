Eagle library for LTC4063
=========================

> Standalone Linear Li-Ion Charger with Micropower Low Dropout Linear Regulator

Eagle (v6.3) library for the LTC4063 Li-Ion Charger by Linear Technology. 

- Datasheet: http://cds.linear.com/docs/en/datasheet/4063fc.pdf
- Product Page: http://www.linear.com/product/LTC4063

License
-------

You are allowed to use the library for everything you want (including the distribution of this files) as long as you keep the Copyright notice in the library.
